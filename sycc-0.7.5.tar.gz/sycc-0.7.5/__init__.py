# __init__.py
# .
import os
import sys as s
from colorama import init
from datetime import datetime as sj
from time import sleep as dd
from math import pi as pai1
from sys import exit as tc
from k.test import now_path,size
start=sj.now()
from p.pdsys import *
from v import *
import socket

#pypi_org()