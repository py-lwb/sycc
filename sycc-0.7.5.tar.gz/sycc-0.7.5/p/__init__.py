from sys import path
path.append('..')
#from e.__init__ import *
from p.beginnings import *
from colorama import init
from datetime import datetime as sj
from time import sleep as dd
from math import pi as pai1
from sys import exit as tc
start=sj.now()

#switch(1)