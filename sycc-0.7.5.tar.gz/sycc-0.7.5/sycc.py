try:
    from core import *
except Exception as sycc_error:
    print('sycc Error:',sycc_error)
#main()