import getpass
password = getpass.getpass("password:")
print(password)