times=3
times = save_v(times,'v.txt')